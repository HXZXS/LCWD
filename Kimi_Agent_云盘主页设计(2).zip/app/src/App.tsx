import './App.css';
import Navbar from './sections/Navbar';
import Hero from './sections/Hero';
import Technology from './sections/Technology';
import Security from './sections/Security';
import Advantages from './sections/Advantages';
import CTA from './sections/CTA';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <section id="hero">
          <Hero />
        </section>
        <section id="technology">
          <Technology />
        </section>
        <section id="security">
          <Security />
        </section>
        <section id="advantages">
          <Advantages />
        </section>
        <CTA />
      </main>
      <Footer />
    </div>
  );
}

export default App;
