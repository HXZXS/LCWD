import { useEffect, useRef, useState } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Globe, 
  Shield, 
  Users, 
  RefreshCw,
  Check,
  X
} from 'lucide-react';

const advantages = [
  {
    icon: TrendingUp,
    title: '可扩展性',
    description: '从个人用户到企业级需求，灵活扩展存储空间'
  },
  {
    icon: DollarSign,
    title: '成本效益',
    description: '相比自建存储，节省高达70%的IT基础设施成本'
  },
  {
    icon: Globe,
    title: '全球访问',
    description: '随时随地通过任何设备访问您的文件'
  },
  {
    icon: Shield,
    title: '安全可靠',
    description: '多重备份机制，数据持久性高达99.9999999%'
  },
  {
    icon: Users,
    title: '团队协作',
    description: '实时共享与协作，提升团队工作效率'
  },
  {
    icon: RefreshCw,
    title: '自动同步',
    description: '文件变更自动同步，无需手动操作'
  }
];

const comparisonData = [
  { feature: '存储空间', us: '免费20GB起', competitor: '免费5GB起' },
  { feature: '单文件大小', us: '无限制', competitor: '最大2GB' },
  { feature: '下载速度', us: '不限速', competitor: '限速100KB/s' },
  { feature: '离线访问', us: '支持', competitor: '付费解锁' },
  { feature: '团队协作', us: '免费支持', competitor: '企业版专属' },
  { feature: 'API接口', us: '开放免费', competitor: '付费使用' },
];

export default function Advantages() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-24 bg-white overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-purple-200 to-transparent" />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <div 
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-50 text-green-700 text-sm font-medium mb-6 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>产品优势</span>
          </div>
          
          <h2 
            className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6 transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            为什么选择<span className="text-gradient">星云云盘</span>
          </h2>
          
          <p 
            className={`text-lg text-gray-600 max-w-2xl mx-auto transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            相比传统云存储服务，我们提供更多功能、更高性能、更优惠价格
          </p>
        </div>

        {/* Advantages grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
          {advantages.map((advantage, index) => (
            <div
              key={advantage.title}
              className={`group p-6 rounded-2xl bg-gray-50 hover:bg-white border border-transparent hover:border-purple-100 hover:shadow-xl transition-all duration-500 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${300 + index * 100}ms` }}
            >
              <div className="w-14 h-14 rounded-xl bg-gradient-purple flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300">
                <advantage.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                {advantage.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {advantage.description}
              </p>
            </div>
          ))}
        </div>

        {/* Comparison table */}
        <div 
          className={`max-w-4xl mx-auto transition-all duration-1000 delay-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
          }`}
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900">与其他云盘对比</h3>
          </div>

          <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
            {/* Table header */}
            <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 border-b border-gray-100">
              <div className="text-sm font-semibold text-gray-600">功能对比</div>
              <div className="text-center">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gradient-purple text-white text-sm font-medium">
                  <span>星云云盘</span>
                </div>
              </div>
              <div className="text-center text-sm font-semibold text-gray-500">其他云盘</div>
            </div>

            {/* Table rows */}
            {comparisonData.map((item, index) => (
              <div 
                key={item.feature}
                className={`grid grid-cols-3 gap-4 p-4 ${
                  index !== comparisonData.length - 1 ? 'border-b border-gray-100' : ''
                }`}
              >
                <div className="flex items-center text-gray-700 font-medium">
                  {item.feature}
                </div>
                <div className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center">
                    <Check className="w-3 h-3 text-green-600" />
                  </div>
                  <span className="text-sm font-medium text-green-700">{item.us}</span>
                </div>
                <div className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center">
                    <X className="w-3 h-3 text-gray-400" />
                  </div>
                  <span className="text-sm text-gray-500">{item.competitor}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Feature image */}
        <div 
          className={`mt-16 relative transition-all duration-1000 delay-900 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'
          }`}
        >
          <div className="relative max-w-4xl mx-auto">
            <div className="absolute -inset-4 bg-gradient-to-r from-purple-500/20 to-green-500/20 rounded-3xl blur-2xl" />
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="/cloud-advantages.jpg" 
                alt="云盘优势展示" 
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
