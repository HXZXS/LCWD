import { useEffect, useRef, useState } from 'react';
import { Shield, Lock, Key, Fingerprint, Eye, FileCheck } from 'lucide-react';

const securityFeatures = [
  {
    icon: Lock,
    title: 'AES-256加密',
    description: '银行级加密标准，确保数据传输与存储安全'
  },
  {
    icon: Key,
    title: '端到端加密',
    description: '您的文件在离开设备前就已加密，只有您能访问'
  },
  {
    icon: Fingerprint,
    title: '双因素认证',
    description: '支持短信、邮箱、 authenticator 多种验证方式'
  },
  {
    icon: Eye,
    title: '隐私保护',
    description: '严格的数据隐私政策，绝不扫描或分析您的文件'
  },
  {
    icon: FileCheck,
    title: '完整性校验',
    description: '自动检测文件完整性，防止数据损坏'
  },
  {
    icon: Shield,
    title: 'DDoS防护',
    description: '企业级DDoS防护，确保服务稳定运行'
  }
];

export default function Security() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-24 bg-gradient-dark overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 right-20 w-96 h-96 bg-purple-600/20 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-20 left-20 w-72 h-72 bg-blue-600/20 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '2s' }} />
        
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px'
          }}
        />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section header */}
        <div className="text-center mb-16">
          <div 
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/20 text-purple-300 text-sm font-medium mb-6 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>数据安全</span>
          </div>
          
          <h2 
            className={`text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6 transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            企业级<span className="text-gradient">安全防护</span>
          </h2>
          
          <p 
            className={`text-lg text-gray-400 max-w-2xl mx-auto transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            您的数据安全是我们的首要任务。采用多重安全机制，全方位保护您的数字资产
          </p>
        </div>

        {/* Content grid */}
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left - Features grid */}
          <div className="grid sm:grid-cols-2 gap-4 order-2 lg:order-1">
            {securityFeatures.map((feature, index) => (
              <div
                key={feature.title}
                className={`group p-5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-500/30 backdrop-blur-sm transition-all duration-500 ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${300 + index * 100}ms` }}
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-purple flex items-center justify-center mb-3 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-base font-semibold text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-400 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>

          {/* Right - Image */}
          <div 
            className={`relative order-1 lg:order-2 transition-all duration-1000 ${
              isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
            }`}
          >
            <div className="relative">
              {/* Glow effect */}
              <div className="absolute -inset-4 bg-gradient-to-br from-purple-500/30 to-cyan-500/30 rounded-3xl blur-2xl animate-pulse-slow" />
              
              {/* Main image */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10">
                <img 
                  src="/security-shield.jpg" 
                  alt="数据安全保护" 
                  className="w-full h-auto"
                />
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-purple-900/30 to-transparent" />
              </div>

              {/* Security badge */}
              <div className="absolute -bottom-4 -left-4 bg-white/10 backdrop-blur-xl rounded-xl p-4 border border-white/20">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-green-400" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">ISO 27001</div>
                    <div className="text-xs text-gray-400">安全认证</div>
                  </div>
                </div>
              </div>

              {/* Another badge */}
              <div className="absolute -top-4 -right-4 bg-white/10 backdrop-blur-xl rounded-xl p-4 border border-white/20">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                    <Lock className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">SSL/TLS</div>
                    <div className="text-xs text-gray-400">传输加密</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Trust indicators */}
        <div 
          className={`mt-16 flex flex-wrap justify-center gap-8 transition-all duration-700 delay-700 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <div className="flex items-center gap-2 text-gray-400">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-sm">GDPR合规</span>
          </div>
          <div className="flex items-center gap-2 text-gray-400">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-sm">SOC 2认证</span>
          </div>
          <div className="flex items-center gap-2 text-gray-400">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-sm">HIPAA兼容</span>
          </div>
          <div className="flex items-center gap-2 text-gray-400">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-sm">等保三级</span>
          </div>
        </div>
      </div>
    </section>
  );
}
