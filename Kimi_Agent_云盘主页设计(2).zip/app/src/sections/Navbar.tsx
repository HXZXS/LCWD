import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Cloud, Menu, X } from 'lucide-react';

const navLinks = [
  { name: '首页', href: '#hero' },
  { name: '技术', href: '#technology' },
  { name: '安全', href: '#security' },
  { name: '优势', href: '#advantages' },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <>
      <nav 
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'bg-white/90 backdrop-blur-xl shadow-lg border-b border-gray-100' 
            : 'bg-transparent'
        }`}
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <a href="#" className="flex items-center gap-2">
              <div className="w-8 h-8 lg:w-10 lg:h-10 rounded-lg bg-gradient-purple flex items-center justify-center">
                <Cloud className="w-5 h-5 lg:w-6 lg:h-6 text-white" />
              </div>
              <span className={`text-lg lg:text-xl font-bold transition-colors ${
                isScrolled ? 'text-gray-900' : 'text-gray-900'
              }`}>
                星云云盘
              </span>
            </a>

            {/* Desktop navigation */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => scrollToSection(link.href)}
                  className={`text-sm font-medium transition-colors hover:text-purple-600 ${
                    isScrolled ? 'text-gray-700' : 'text-gray-700'
                  }`}
                >
                  {link.name}
                </button>
              ))}
            </div>

            {/* Desktop CTA buttons */}
            <div className="hidden lg:flex items-center gap-4">
              <a 
                href="http://LCWD.rth1.xyz/login.html" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button 
                  variant="ghost" 
                  className={`text-sm font-medium ${
                    isScrolled ? 'text-gray-700' : 'text-gray-700'
                  }`}
                >
                  登录
                </Button>
              </a>
              <a 
                href="http://LCWD.rth1.xyz/RUN.html" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Button 
                  className="bg-gradient-purple hover:opacity-90 text-white text-sm px-6"
                >
                  免费注册
                </Button>
              </a>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6 text-gray-700" />
              ) : (
                <Menu className="w-6 h-6 text-gray-700" />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile menu */}
      <div 
        className={`fixed inset-0 z-40 lg:hidden transition-all duration-300 ${
          isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        {/* Backdrop */}
        <div 
          className="absolute inset-0 bg-black/50 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        />
        
        {/* Menu panel */}
        <div 
          className={`absolute top-16 left-0 right-0 bg-white shadow-xl border-b border-gray-100 transition-transform duration-300 ${
            isMobileMenuOpen ? 'translate-y-0' : '-translate-y-full'
          }`}
        >
          <div className="container mx-auto px-4 py-6">
            <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <button
                  key={link.name}
                  onClick={() => scrollToSection(link.href)}
                  className="text-left text-gray-700 font-medium py-2 hover:text-purple-600 transition-colors"
                >
                  {link.name}
                </button>
              ))}
              <hr className="border-gray-100 my-2" />
              <a 
                href="http://LCWD.rth1.xyz/login.html" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full"
              >
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  登录
                </Button>
              </a>
              <a 
                href="http://LCWD.rth1.xyz/RUN.html" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full"
              >
                <Button 
                  className="w-full bg-gradient-purple hover:opacity-90 text-white"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  免费注册
                </Button>
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
